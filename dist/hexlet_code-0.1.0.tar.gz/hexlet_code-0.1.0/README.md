### Hexlet tests and linter status:
[![Actions Status](https://github.com/bibilnikova/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bibilnikova/python-project-49/actions)

<a href="https://codeclimate.com/github/bibilnikova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/db0ecf0026348f0b5abc/maintainability" /></a>

brain-games + brain-even: https://asciinema.org/a/uDA97XVjdMY4AQTJAwQDyZVpI

brain-calc: https://asciinema.org/a/wBrYsdVRfatWFQTKMow5IWv3q

brain-gcd: https://asciinema.org/a/v1utgPOkebYC5AA3rizrjEzxj

brain-progression: https://asciinema.org/a/T41EWz4sDPba0IqWoly2CnSdB

brain-prime: https://asciinema.org/a/QWVXi7HrK9rLrrROevLXqDRla
